import { SET_USER, UPDATE_COINS } from '../actions/types';

const initialState = {
    telegramId: '',
    coins: 0
};

export default function(state = initialState, action) {
    switch (action.type) {
        case SET_USER:
            return {
                ...state,
                telegramId: action.payload,
                coins: localStorage.getItem(action.payload) 
                    ? JSON.parse(localStorage.getItem(action.payload)).coins 
                    : 100000 
            };
        case UPDATE_COINS:
            const newCoins = state.coins + action.payload;
            localStorage.setItem(state.telegramId, JSON.stringify({ ...state, coins: newCoins }));
            return {
                ...state,
                coins: newCoins
            };
        default:
            return state;
    }
}
