import { combineReducers } from 'redux';
import coinsReducer from './coinsReducer';
import taskReducer from './taskReducer';
import userReducer from './userReducer';

export default combineReducers({
    user: userReducer,
    task: taskReducer
});
