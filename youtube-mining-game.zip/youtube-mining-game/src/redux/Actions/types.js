export const UPDATE_COINS = 'UPDATE_COINS';
export const SET_TASK = 'SET_TASK';
export const SET_USER = 'SET_USER';

