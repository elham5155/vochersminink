import { UPDATE_COINS, SET_TASK, SET_USER } from './types';

export const updateCoins = (coins) => ({
    type: UPDATE_COINS,
    payload: coins
});

export const setTask = (task) => ({
    type: SET_TASK,
    payload: task
});

export const setUser = (user) => ({
    type: SET_USER,
    payload: user
});

