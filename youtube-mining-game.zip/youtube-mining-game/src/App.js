import React, { useEffect } from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import Navbar from './components/Navbar';
import Game from './components/Game';
import Task from './components/Task';
import { setUser } from './redux/actions';
import './styles/App.css';

const App = () => {
    const dispatch = useDispatch();

    useEffect(() => {
        // Simulate getting a Telegram ID
        const telegramId = 'user12345'; // Replace this with actual Telegram ID fetching logic
        dispatch(setUser(telegramId));
    }, [dispatch]);

    return (
        <Router>
            <div className="App">
                <Navbar />
                <Switch>
                    <Route path="/" exact component={Game} />
                    <Route path="/task" component={Task} />
                </Switch>
            </div>
        </Router>
    );
};

export default App;


