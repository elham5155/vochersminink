import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { updateCoins, setTask } from '../redux/actions';
import './styles/Task.css';

const Task = () => {
    const task = useSelector(state => state.task.task);
    const dispatch = useDispatch();

    const handleTaskCompletion = () => {
        dispatch(updateCoins(10000)); // Increment coins by 10,000 for completing task
    };

    return (
        <div className="task-page">
            <h2>Today's Task</h2>
            <p>{task}</p>
            <a
                href={task}
                target="_blank"
                rel="noopener noreferrer"
                className="task-link"
                onClick={handleTaskCompletion}
            >
                Complete Task
            </a>
        </div>
    );
};

export default Task;

