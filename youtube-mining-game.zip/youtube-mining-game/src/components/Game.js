import React from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { updateCoins } from '../redux/actions';
import './styles/Game.css';

const Game = () => {
    const dispatch = useDispatch();
    const user = useSelector(state => state.user);

    const handleMining = () => {
        dispatch(updateCoins(10000)); // Increment coins by 10,000 for each task
    };

    return (
        <div className="game">
            <button onClick={handleMining} className="mine-button">
                Mine YouTube Coins
            </button>
            <div>
                <p>{user.telegramId}</p>
            </div>
        </div>
    );
};

export default Game;
