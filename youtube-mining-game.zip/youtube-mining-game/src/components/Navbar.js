import React from 'react';
import { useSelector } from 'react-redux';
import './styles/Navbar.css';

const Navbar = () => {
    const coins = useSelector(state => state.user.coins);
    return (
        <div className="navbar">
            <img src="/assets/images/youtube-logo.png" alt="YouTube Logo" className="logo" />
            <div className="coins">Coins: {coins}</div>
        </div>
    );
};

export default Navbar;

